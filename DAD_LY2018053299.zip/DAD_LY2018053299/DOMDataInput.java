package com.ly.controller;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.*;

public class DOMTest {

    public static void main(String[] args) throws SQLException {
        //1、创建一个DocumentBuilderFactory的对象
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        //2、创建一个DocumentBuilder的对象
        try {
            //创建DocumentBuilder对象
            DocumentBuilder db = dbf.newDocumentBuilder();
            //3、通过DocumentBuilder对象的parser方法加载books.xml文件到当前项目下
            /*注意导入Document对象时，要导入org.w3c.dom.Document包下的*/
            Document document = db.parse("BIOMD0000000011_url.xml");//传入文件名可以是相对路径也可以是绝对路径
            //获取所有book节点的集合
            NodeList bookList = document.getElementsByTagName("tr");
            //通过nodelist的getLength()方法可以获取bookList的长度
            //遍历每一个book节点
            String[][] res = new String[50][3];
            for (int i = 3; i < bookList.getLength()-23; i++) {
                //❤未知节点属性的个数和属性名时:
                //通过 item(i)方法 获取一个book节点，nodelist的索引值从0开始
                Node book = bookList.item(i);
                //获取book节点的所有属性集合
                NamedNodeMap attrs = book.getAttributes();
                //解析book节点的子节点
                NodeList childNodes = ((Node) book).getChildNodes();
                for (int k = 0; k < childNodes.getLength(); k++) {
                    //区分出text类型的node以及element类型的node
                    if(childNodes.item(k).getNodeType() == Node.ELEMENT_NODE){
                        String line = childNodes.item(k).getFirstChild().getNodeValue();
                        //line = line.substring(7,line.length());
                        if(k==3) {
                            String[] strings = line.split("\\+|->");
                            for (String string : strings) {
                                //System.out.print(string);

                            }
                            res[i][0]=strings[0];
                            res[i][1]=strings[1];
                            res[i][2]=strings[2];

                        }

                    }
                }
            }
            Database database = new Database();
            Connection con = database.connect();
            Statement stmt = con.createStatement() ;
            ResultSet resultSet;
            for (int i = 3 ; i < res.length-37; i++) {
                String s0, s1, s2;
                s0 = res[i][0];
                s1 = res[i][1];
                s2 = res[i][2];
                String sql1 = "insert into levam(element,"+s1+") values("+"'"+s0+"'"+",1)";
                stmt.execute(sql1);
                System.out.println(sql1);
            }
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

