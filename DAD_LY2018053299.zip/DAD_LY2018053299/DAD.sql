create table LevAM(
element varchar(15) not null,
MAPKpp smallint default 0,
MAPKPH smallint default 0,
RAF smallint default 0,
RAFK smallint default 0,
RAFp smallint default 0,
RAFPH smallint default 0,
MEK smallint default 0,
MEKp smallint default 0,
MEKPH smallint default 0,
MEKpp smallint default 0,
MAPK smallint default 0,
RAFRAFK smallint default 0
)
